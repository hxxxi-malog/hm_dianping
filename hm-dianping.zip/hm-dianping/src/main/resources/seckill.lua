
--local voucherId = ARGV[1]
--local userId = ARGV[2]

-- local stockKey = 'seckill:stock:' .. voucherId
-- local orderKey = 'seckill:order:' .. voucherId
--
-- -- 获取库存数量，如果键不存在则返回0
-- local stock = tonumber(redis.call('get', stockKey)) or 0
--
-- if stock <= 0 then
--     return 1 -- 库存不足
-- end
--
-- if redis.call('sismember', orderKey, userId) == 1 then
--     return 2 -- 用户已购买
-- end
--
-- -- 减少库存数量
-- redis.call('decrby', stockKey, 1)
-- -- 将用户 ID 添加到订单集合中
-- redis.call('sadd', orderKey, userId)
--
-- return 0 -- 操作成功




--
--local voucherId = ARGV[1]
--local userId = ARGV[2]
--
--local stockKey = 'seckill:stock:' .. voucherId
--local orderKey = 'seckill:order:' .. voucherId
--
--if(tonumber(redis.call('get', stockKey)) <= 0) then
--    return 1
--end
--
--if(redis.call('sismember', orderKey, userId) == 1) then
--    return 2
--end
--
--redis.call('incrby', stockKey, -1)
--redis.call('sadd', orderKey, userId)
--
--return 0


local voucherId = ARGV[1]
local userId = ARGV[2]
local orderId = ARGV[3]

local stockKey = 'seckill:stock:' .. voucherId
local orderKey = 'seckill:order:' .. voucherId

-- 处理库存不存在的情况（兼容初始化逻辑）
local stock = tonumber(redis.call('get', stockKey)) or 0
if stock <= 0 then
    return 1 -- 与VoucherServiceImpl中的库存初始化逻辑保持一致
end

-- 检查用户是否已下单（幂等性校验）
if redis.call('sismember', orderKey, userId) == 1 then
    return 2
end

-- 原子操作保证库存扣减和订单记录
redis.call('decrby', stockKey, 1)     -- 修改为更直观的减库存操作
redis.call('sadd', orderKey, userId)  -- 记录用户购买行为
redis.call('xadd', 'stream.orders', '*', userId, 'voucherId', voucherId, 'id', orderId)

return 0


